This repo contains data and lessons materials for the NCSU Software Carpentry workshop in Jan 2015. 

Website: http://kcranston.github.io/2015-01-29-ncsu/

