# Time estimates for instructors

* n = 5
* median = 4.5 hours

# Resources

*   `inflammation-*.csv`: data files used in notebooks.
*   `readings-*.py`: successive versions of command-line script.
*   `small-*.csv`: small data files used to test command-line script.
*   `argv-list.py`: example command-line script.
*   `count-stdin.py`: example command-line script.
*   `sys-version.py`: example command-line script.
*   `img/*`: images used in notebooks
