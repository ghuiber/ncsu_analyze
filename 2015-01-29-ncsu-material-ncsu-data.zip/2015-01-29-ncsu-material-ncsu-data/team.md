---
layout: lesson
root: .
title: Our Team
---
Many thanks to all of the people who have contributed to Software Carpentry over the years.

<table width="100%">
<tr>
<td valign="top">
Nasser Mohieddin Abukhdeir
<br/>
Joshua Adelman
<br/>
Aron Ahmadia
<br/>
Joshua Ainsley
<br/>
Carlos Anderson
<br/>
Mario Antonioletti
<br/>
Feth Arezki
<br/>
Dhavide Aruliah
<br/>
Pauline Barmby
<br/>
Diego Barneche
<br/>
Philipp Bayer
<br/>
Trevor Bekolay
<br/>
Miguel Bernabeu
<br/>
Matt Billard
<br/>
Sergi Blanco Cuaresma
<br/>
John Blischak
<br/>
Darren Boss
<br/>
Azalee Bostroem
<br/>
Erik Bray
<br/>
Eli Bressert
<br/>
Matthew Brett
<br/>
Amy Brown
<br/>
C. Titus Brown
<br/>
Jennifer Bryan
<br/>
Orion Buske
<br/>
Rosangela Canino-Koning
<br/>
Chris Cannam
<br/>
Scott Chamberlain
<br/>
Cliburn Chan
<br/>
Amanda Charbonneau
<br/>
Shreyas Cholia
<br/>
Adina Chuang Howe
<br/>
Neil Chue Hong
<br/>
Rodgers Cliff
<br/>
Christophe Combelles
<br/>
Mike Conley
<br/>
Christophe Cossou
<br/>
Stefano Cozzini
<br/>
Karen Cranston
<br/>
Stephen Crouch
<br/>
Davor Cubranic
<br/>
Emily Davenport
<br/>
Matt Davis
<br/>
Neal Davis
<br/>
Gabriel Devenyi
<br/>
Ross Dickson
<br/>
Jonah Duckles
<br/>
Jonathan Dursi
<br/>
Curtis Dyreson
<br/>
Stephen J. Eglen
<br/>
Justin Ely
<br/>
Dethe Elza
<br/>
Remi Emonet
<br/>
Richard Enbody
<br/>
Julia Evans
<br/>
Milad Fatenejad
<br/>
Luis Figueira
<br/>
Mike Fletcher
<br/>
Fernanda Foertter
<br/>
Patrick Fuller
<br/>
Julian Garcia
</td>
<td valign="top">
Laurent Gatto
<br/>
Molly Gibson
<br/>
Matt Gidden
<br/>
Ivan Gonzalez
<br/>
Alexandre Gramfort
<br/>
Chris Gray
<br/>
Julia Gustavsen
<br/>
Tommy Guy
<br/>
Steven Haddock
<br/>
Michael Hansen
<br/>
Ted Hart
<br/>
Trent Hauck
<br/>
Elliott Hauser
<br/>
James Hetherington
<br/>
Konrad Hinsen
<br/>
Steve Holden
<br/>
Mark Holder
<br/>
Preston Holmes
<br/>
Alison Hoyt
<br/>
Katy Huff
<br/>
Damien Irving
<br/>
Paul Ivanov
<br/>
Mike Jackson
<br/>
David Jones
<br/>
Nick Jones
<br/>
Jessica Kerr
<br/>
David Ketcheson
<br/>
W. Trevor King
<br/>
Justin Kitzes
<br/>
Christina Koch
<br/>
Steven Koenig
<br/>
Bernhard Konrad
<br/>
David Koop
<br/>
Daniel Krasner
<br/>
Karin Lagesen
<br/>
Jared Lander
<br/>
Ian Langmore
<br/>
Chris Lasher
<br/>
Doug Latornell
<br/>
Michelle Levesque
<br/>
Phil Lies
<br/>
Nicolas Limare
<br/>
Yuxi Luo
<br/>
Cath Ly
<br/>
Cam Macdonell
<br/>
Cindee Madison
<br/>
Kyle Mandli
<br/>
David Martin
<br/>
Dan McGlinn
<br/>
Steve McGough
<br/>
Jessica McKellar
<br/>
Tim McNamara
<br/>
Emily Jane McTavish
<br/>
Aronne Merrelli
<br/>
Lauren Michael
<br/>
Ian Mitchell
<br/>
Ben Morris
<br/>
James Morrison
<br/>
R. David Murray
<br/>
Sri Hari Krishna Narayanan
</td>
<td valign="top">
Lex Nederbragt
<br/>
Victor Ng
<br/>
Charlene Nielsen
<br/>
Danielle Nielsen
<br/>
Randy Olson
<br/>
Geoff Oxberry
<br/>
Aleksandra Pawlik
<br/>
Jason Pell
<br/>
Fernando Perez
<br/>
Hans Petter Langtangen
<br/>
Caitlyn Pickens
<br/>
Bill Punch
<br/>
Karthik Ram
<br/>
David Rio Deiros
<br/>
Ariel Rokem
<br/>
Jorden Schossau
<br/>
Anthony Scopatz
<br/>
Michael Selik
<br/>
Chang She
<br/>
Jeffrey Shelton
<br/>
Raniere Silva
<br/>
Gavin Simpson
<br/>
Andrew Smith
<br/>
Joshua Ryan Smith
<br/>
Jon Speicher
<br/>
Adam Stark
<br/>
Becky Stewart
<br/>
Shoaib Sufi
<br/>
Sarah Supp
<br/>
Leszek Tarkowski
<br/>
Tracy Teal
<br/>
Andy Terrel
<br/>
Matt Terry
<br/>
Samuel Thomson
<br/>
Joan Touzet
<br/>
Laura Tremblay-Boyer
<br/>
Will Trimble
<br/>
Jacob Vanderplas
<br/>
Gael Varoquaux
<br/>
Nelle Varoquaux
<br/>
Alex Viana
<br/>
Jens von der Linden
<br/>
Dominique Vuvan
<br/>
David Warde-Farley
<br/>
Ben Waugh
<br/>
Eric Weinstein
<br/>
Ethan White
<br/>
Rick White
<br/>
Amanda Whitlock
<br/>
Lynne Williams
<br/>
Greg Wilson
<br/>
Paul Wilson
<br/>
Sasha Wood
<br/>
Christopher Woods
<br/>
April Wright
<br/>
Andromeda Yelton
<br/>
Enas Yunis
<br/>
Qingpeng Zhang
<br/>
Naupaka Zimmerman
</td>
</tr>
</table>
